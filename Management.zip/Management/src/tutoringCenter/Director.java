package tutoringCenter;

public class Director {
	
//	Director (int id, String nm, String ce, String cp) {
//		super (id, nm, ce, cp);
//	}

}
