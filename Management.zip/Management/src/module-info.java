module management {
	requires java.base;
}